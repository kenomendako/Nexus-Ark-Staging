# Nexus Ark ユーザーガイド

この文書群は、Nexus Arkのユーザー向け説明の正本です。
公式サイトのガイドページと、案内役ペルソナ「オリヴェ」の同梱ナレッジは、ここから機械的に生成・同期します。
機能名やメニュー位置は、アプリの実UIラベルに合わせて更新してください。

## 目次

1. [はじめに](00_getting_started.md)
2. [最初の設定ガイド](01_initial_settings.md)
3. [画面構成と基本操作](02_ui_overview.md)
4. [チャットとログ管理](03_chat_and_logs.md)
5. [記憶・ノート・知識](04_memory_notes_knowledge.md)
6. [自律行動・ウォッチリスト・委任](05_autonomy_delegation_atelier.md)
7. [クローゼット・アイテム](06_closet_items.md)
8. [外部接続とNexus Ark Lite](07_external_connections_lite.md)
9. [AIモデル・APIキー・コスト管理](08_models_api_costs.md)
10. [通知・時間管理・カレンダー・天気](09_notifications_time_calendar_weather.md)
11. [お出かけ・インポート・エクスポート](10_outing_import_export.md)
12. [トラブルシューティング](11_troubleshooting.md)

## 同期コマンド

正本をオリヴェの同梱ナレッジへ同期します。

```bash
.venv/bin/python dev_tools/sync_user_guide.py
```

サイト用HTMLを生成します。

```bash
.venv/bin/python dev_tools/build_site_guide.py
```

インストール済みのオリヴェルームへも同期する場合は、通常ルーム `characters/Olivie` または `characters/オリヴェ` が存在する状態で明示的に指定します。

```bash
.venv/bin/python dev_tools/sync_user_guide.py --sync-installed-room
```

オリヴェのRAG索引まで再構築する場合は、Embeddingに使うAPIキーが設定されている状態で実行します。

```bash
.venv/bin/python dev_tools/sync_user_guide.py --rebuild-index
```

## 運用ルール

ユーザーに見える機能、UI、設定項目を変更した場合は、完了前に該当するページを更新したか確認してください。
メニュー位置を書くときは、`nexus_ark.py` の実レイアウトと突き合わせ、絵文字を含むラベルを正確に書きます。
`visible=False` のタブや実験中で非表示の設定には、ユーザーを誘導しません。

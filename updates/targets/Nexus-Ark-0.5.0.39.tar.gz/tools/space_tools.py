# tools/space_tools.py (v20: Final Architecture)

import os
import re
from langchain_core.tools import tool
from room_manager import get_world_settings_path
import utils
import constants
from typing import List, Dict, Any
import traceback


def _format_value_as_text(value: Any, indent: int = 0) -> str:
    """
    AIから渡された値（文字列または辞書）を、元のYAML風階層テキスト形式に変換する。
    辞書の場合は再帰的に処理し、改行とインデントを適切に付与する。
    """
    if value is None:
        return ""
    
    if isinstance(value, str):
        return value
    
    if isinstance(value, (int, float, bool)):
        return str(value)
    
    if isinstance(value, list):
        # リストの各要素を処理
        lines = []
        for item in value:
            if isinstance(item, dict):
                # 辞書要素は改行して表示
                lines.append("")  # 空行で区切る
                lines.append(_format_value_as_text(item, indent + 2))
            else:
                lines.append("  " * indent + str(item))
        return "\n".join(lines)
    
    if isinstance(value, dict):
        lines = []
        for key, val in value.items():
            prefix = "  " * indent
            # キーを特殊処理（comment/description系はコメント行として扱う）
            if key == "comment" or key.startswith("//"):
                lines.append(f"{prefix}{val}")
            elif isinstance(val, dict):
                lines.append(f"{prefix}{key}: ")
                lines.append(_format_value_as_text(val, indent + 1))
            elif isinstance(val, list):
                lines.append(f"{prefix}{key}: ")
                lines.append(_format_value_as_text(val, indent + 1))
            else:
                lines.append(f"{prefix}{key}: {val}")
        return "\n".join(lines)
    
    # その他の型は文字列化
    return str(value)


@tool
def list_available_locations(room_name: str) -> str:
    """
    現在移動可能な世界内の「エリア」と「場所」の一覧を取得します。
    別の場所に移動（set_current_location）する前に、どのような場所があるか確認するために使用します。
    """
    if not room_name:
        return "【Error】Internal tool error: room_name is required for execution."

    world_settings_path = get_world_settings_path(room_name)
    world_data = utils.parse_world_file(world_settings_path)
    if not world_data:
        return f"【Error】世界設定ファイルが見つからないか、空です。ルーム '{room_name}' を確認してください。"

    lines = []
    for area, places in world_data.items():
        if isinstance(places, dict):
            valid_places = [p for p in places.keys() if not p.startswith("__")]
            if valid_places:
                lines.append(f"■ {area}")
                for place in valid_places:
                    lines.append(f"  - {place}")

    if not lines:
        return "【情報】現在、移動可能な場所は定義されていません。"

    result = "【移動可能なエリアと場所の一覧】\n" + "\n".join(lines)
    result += "\n\n※移動するには set_current_location の location_id に、上の場所名をそのまま指定してください。"    
    return result


@tool
def set_current_location(location_id: str, room_name: str) -> str:
    """AIの現在地を設定する。location_idには、利用可能な場所の名前だけを正確に指定する必要がある。"""
    if not location_id or not room_name:
        return "【Error】Internal tool error: Location ID and room name are required for execution."

    # 1. 有効な場所名のリストを世界設定から取得する
    world_settings_path = get_world_settings_path(room_name)
    world_data = utils.parse_world_file(world_settings_path)
    if not world_data:
        return f"【Error】世界設定ファイルが見つからないか、空です。ルーム '{room_name}' を確認してください。"

    valid_locations = {} # {place_name: area_name}
    for area in world_data:
        for place in world_data[area]:
            if not place.startswith("__"):
                valid_locations[place] = area

    if not valid_locations:
        return "【Error】世界設定ファイルに、移動可能な場所が一つも定義されていません。"

    # 2. AIからの入力を解釈し、正しい場所名に補正する
    original_input = location_id.strip()
    corrected_location_id = None

    # 2a. 完全一致を試みる
    if original_input in valid_locations:
        corrected_location_id = original_input

    # 2b. 一般的な間違いパターンを吸収する
    if not corrected_location_id:
        # `[エリア名] 場所名` や `[エリア名]場所名` の形式を想定し、括弧とエリア名を除去
        cleaned_input = re.sub(r'\[.*?\]', '', original_input).strip()
        if cleaned_input in valid_locations:
            corrected_location_id = cleaned_input
        else:
            # `エリア名 場所名` の形式を想定し、最後の単語を試す
            parts = cleaned_input.split()
            if len(parts) > 1 and parts[-1] in valid_locations:
                corrected_location_id = parts[-1]
            else:
                 # `エリア名場所名` のような連結形式を想定し、後方一致で探す
                 for loc in valid_locations:
                     if cleaned_input.endswith(loc):
                         corrected_location_id = loc
                         break

    # 2c. ファジーマッチ（部分一致・英語名推測への対応）
    if not corrected_location_id:
        input_lower = original_input.lower().replace('_', ' ').replace('-', ' ')
        best_match = None
        best_score = 0
        for loc in valid_locations:
            loc_lower = loc.lower()
            # 場所名が入力に含まれている（例: 「植物園」→「硝子張りの植物園」）
            if loc_lower in input_lower or input_lower in loc_lower:
                score = len(loc)  # 長い方が具体的な一致
                if score > best_score:
                    best_match = loc
                    best_score = score
        if best_match:
            corrected_location_id = best_match

    # 3. 補正後のIDでファイルに書き込む
    if corrected_location_id:
        try:
            base_path = os.path.join(constants.ROOMS_DIR, room_name)
            location_file_path = os.path.join(base_path, "current_location.txt")
            with open(location_file_path, "w", encoding="utf-8") as f:
                f.write(corrected_location_id)
            
            # 4. 移動先の情景を取得してAIに渡す
            area_name = valid_locations[corrected_location_id]
            scene_description = world_data[area_name].get(corrected_location_id, "情景描写が定義されていません。")
            
            # 補正が行われた場合はその旨を伝える
            correction_note = ""
            if corrected_location_id != original_input:
                correction_note = f"（入力 '{original_input}' → '{corrected_location_id}' に補正しました）\n"
            
            return (f"Success: 現在地は '{corrected_location_id}' に設定されました。{correction_note}"
                    f"**以下の【移動後の情景】が、今のあなたの目に映る光景です。**\n\n"
                    f"【移動後の情景】\n{scene_description}\n\n"
                    f"※注意: 「移動しました」といったシステム的な報告は最小限にし、新しい場所での体験を重視して応答してください。")
        except Exception as e:
            return f"【Error】現在地のファイル書き込みに失敗しました: {e}"
    else:
        # 5. 全ての試みが失敗した場合、AIに明確なエラーと選択肢を返す
        valid_locations_str = ", ".join(f"'{loc}'" for loc in sorted(list(set(valid_locations.keys()))))
        return (f"【Error】指定された場所 '{original_input}' は見つかりませんでした。"
                f"location_idには、以下のいずれかを正確に指定してください: {valid_locations_str}")

def _apply_world_edits(instructions: List[Dict[str, Any]], room_name: str) -> str:
    """【内部専用】AIが生成した世界設定への差分編集指示リストを解釈し、world_settings.txtに適用する。"""

    if not room_name: return "【エラー】ルーム名が指定されていません。"

    world_settings_path = get_world_settings_path(room_name)
    world_data = utils.parse_world_file(world_settings_path)

    try:
        applied_changes = []
        for i, inst in enumerate(instructions):
            op = inst.get("operation", "").lower()
            area = inst.get("area_name")
            place = inst.get("place_name")
            value = inst.get("value")

            if not op or not area:
                return f"【エラー】指示 {i+1} に 'operation' または 'area_name' がありません。"

            op_label = ""
            if op == "update_place_description":
                if not place or value is None: return f"【エラー】指示 {i+1} (update) に 'place_name' または 'value' がありません。"
                world_data.setdefault(area, {})[place] = _format_value_as_text(value)
                op_label = "更新"
            elif op == "append_place_description":
                if not place or value is None: return f"【エラー】指示 {i+1} (append) に 'place_name' または 'value' がありません。"
                existing = world_data.setdefault(area, {}).get(place, "")
                if existing:
                    world_data[area][place] = f"{existing}\n{_format_value_as_text(value)}"
                else:
                    world_data[area][place] = _format_value_as_text(value)
                op_label = "追記"
            elif op == "add_place":
                if not place or value is None: return f"【エラー】指示 {i+1} (add_place) に 'place_name' または 'value' がありません。"
                world_data.setdefault(area, {})[place] = _format_value_as_text(value)
                op_label = "追加"
            elif op == "delete_place":
                if not place: return f"【エラー】指示 {i+1} (delete_place) に 'place_name' がありません。"
                if area in world_data and place in world_data[area]:
                    del world_data[area][place]
                op_label = "削除"
            elif op == "patch_place_description":
                # 部分編集: find/replace を使って特定箇所のみを置換
                find_text = inst.get("find")
                replace_text = inst.get("replace")
                if not place: return f"【エラー】指示 {i+1} (patch) に 'place_name' がありません。"
                if find_text is None or replace_text is None: 
                    return f"【エラー】指示 {i+1} (patch) に 'find' または 'replace' がありません。"
                
                if area not in world_data or place not in world_data[area]:
                    return f"【エラー】指示 {i+1}: 場所 '{place}' がエリア '{area}' に存在しません。"
                
                current_content = world_data[area][place]
                if find_text not in current_content:
                    return f"【エラー】指示 {i+1}: 検索テキスト '{find_text[:50]}...' が場所 '{place}' の内容に見つかりません。"
                
                # 置換を実行（最初の一致のみ）
                world_data[area][place] = current_content.replace(find_text, _format_value_as_text(replace_text), 1)
                op_label = "修正"
            else:
                return f"【エラー】指示 {i+1} の操作 '{op}' は無効です。"
            
            applied_changes.append(f"[{op_label}] {area} > {place}")

        # world_builderのsave_world_dataを再利用してファイルに書き込む
        from world_builder import save_world_data
        save_world_data(room_name, world_data) 

        summary_lines = "\n".join([f"- {change}" for change in applied_changes])
        return f"成功: 以下の変更を世界設定(world_settings.txt)に適用しました：\n{summary_lines}"

    except Exception as e:
        traceback.print_exc()
        return f"【エラー】世界設定の編集中に予期せぬエラーが発生しました: {e}"

from pydantic import BaseModel, Field

class PlanWorldEditArgs(BaseModel):
    modification_request: str = Field(..., description="世界に対してどのような変更を行いたいかの「意図」や具体的な指示。")
    room_name: str = Field(..., description="対象のルーム名")

@tool(args_schema=PlanWorldEditArgs)
def plan_world_edit(modification_request: str, room_name: str) -> str:
    """
    【ステップ1：計画】現在の世界設定（world_settings.txt）の変更を計画します。
    このツールは、あなたが世界に対してどのような変更を行いたいかの「意図」をシステムに伝えるために、最初に呼び出します。
    """
    return f"システムへの世界設定編集計画を受け付けました。意図:「{modification_request}」"

@tool
def read_world_settings(room_name: str) -> str:
    """
    現在の世界設定（world_settings.txt）の全文をテキスト形式で読み取る。
    主に、編集以外の目的で内容を確認したい場合に使用します。
    """
    if not room_name: return "【Error】Internal tool error: room_name is required for execution."
    world_settings_path = get_world_settings_path(room_name)
    if not world_settings_path or not os.path.exists(world_settings_path):
        return f"【Error】Could not find world settings file for room '{room_name}'."
    try:
        with open(world_settings_path, "r", encoding="utf-8") as f: content = f.read()
        return content if content.strip() else "【情報】世界設定ファイルは空です。"
    except Exception as e: return f"【Error】Failed to read world settings file: {e}"

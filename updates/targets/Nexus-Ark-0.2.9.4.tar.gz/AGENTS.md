# Nexus Ark — AIエージェント共通開発ルール（正本）

このファイルは、Nexus Arkで作業する**すべてのAIエージェント**（Claude Code / Codex /
Antigravity / その他）が遵守するルールの**唯一の正本**である（ADR 020）。
`CLAUDE.md`・`.agents/`・`.agent/` の各ルールファイルは本ファイルへの参照であり、
ルールの追加・変更は必ず本ファイルに対して行う。

---

## 0. 基本原則

### 言語

- ユーザーへの応答、コミットメッセージ、レポートは**日本語**で記述する。
- コード識別子・引用が英語でも、応答・思考アウトプットは日本語にする。

### 対話と確認

- **相談・質問**にはまず回答と提案を返す。実装はユーザーが「やってください」と明示した後。
- マージ、`origin` への push、破壊的操作は必ずユーザーの明示的な許可を得てから行う。

### ドキュメント第一

コーディング前に関連ドキュメントを確認する。UI変更の場合は必読（§4）。

---

## 1. Git 規約

### ブランチ戦略

- **`main` への直接コミットは禁止。** タスクごとに作業ブランチを作る。
- ブランチ名: `[prefix]/[task-name-kebab-case]`

| prefix | 用途 |
|---|---|
| `feat/` | 新機能 |
| `fix/` | バグ修正 |
| `improve/` | 改善・リファクタリング |
| `docs/` | ドキュメントのみ |

### コミットメッセージ

- 言語: 日本語
- 形式: `[prefix]: [変更内容の簡潔な説明]`
- 例: `fix: メモリ検索の重複バグを修正`

### リモート

- 開発用: `gradiotest`（通常の push 先）
- 公開用: `origin`（**明示許可なしに push しない**。公開＝配布なので慎重に）

### 共有作業ツリーの注意

複数のエージェントが**同じ作業ツリー**を使うことがある。

- コミット・checkout・merge の直前に必ず `git branch --show-current` で現在ブランチを確認する。
- 他のエージェントが作業中とユーザーから知らされている間は、git の状態を変更しない。

---

## 2. 開発フロー

### タスク開始

1. `git status --short` で未コミット変更を確認・記録する。
2. 作業ブランチを作成: `git checkout -b [branch-name]`
3. 関連ドキュメントと既存コードを読んでから実装に入る。

### タスク完了・レポート

1. `docs/reports/YYYY/MM/YYYY-MM-DD_[TaskName].md` を作成。
2. `CHANGELOG.md`（Unreleased セクション）にエントリを追記。
3. `docs/STATUS.md` を更新（最終更新・最近完了タスク・次タスク）。
4. `docs/plans/TASK_LIST.md` の対象タスクを `[x]` にする。
5. 記憶システムに関わる変更の場合、`docs/specs/MEMORY_SYSTEM_SPECIFICATION.md` の
   該当節と更新履歴を更新したか確認する。
6. ユーザーに見える機能・UI・設定項目を変更した場合、ユーザー向けドキュメント
   （正本: `docs/user_guide/`）を更新したか確認する（ADR 019）。
7. 変更を検証してからコミット（検証手順は下記）。
8. マージや push はユーザーの許可後に行う。

### 検証コマンド

```bash
# 構文チェック
.venv/bin/python -m py_compile [変更したPythonファイル]

# テスト
.venv/bin/python -m pytest [対象テスト]

# UI配線チェック（UI変更時は必須）
.venv/bin/python dev_tools/validate_wiring.py
```

> `python` / `python3` で依存関係が見つからない場合は `.venv/bin/python` で再実行する。

---

## 3. バージョン管理

- `version.json` のバージョン番号は**配布パッケージ作成時にのみ**変更する。
- 日常のバグ修正・機能実装・ドキュメント更新では変更しない。
- バージョン形式: `MAJOR.MINOR.PATCH.BUILD`
- リリース手順の詳細: `.agents/workflows/release-update.md`

---

## 4. UI 開発の鉄則

UI を変更する場合は `docs/guides/gradio_notes.md` と `docs/guides/UI_IMPLEMENTATION_PATTERNS.md` を先に確認すること。

### 責務の分離

| ファイル | 責務 |
|---|---|
| `nexus_ark.py` | レイアウトとイベント配線のみ |
| `ui_handlers.py` | ハンドラ・ロジック・戻り値生成 |
| `config_manager.py` | 共通設定・定数・設定ロード/保存 |

### イベントハンドラ契約

- 出力数の不整合は起動クラッシュの原因になる。`_ensure_output_count` を活用する。
- 広範囲の UI 更新は司令塔パターン（単一の司令塔関数）で行う。

### 状態管理

- UI セッション依存値は `gr.State` を使う。グローバル変数への安易な依存禁止。
- `gr.Chatbot` は現行コードで `render_markdown=True` を明示している。複雑なHTML表示は
  Python 側で生成しつつ、Markdown再解釈で崩れないよう必要箇所をHTMLエスケープする。

### 設定保存

- UI 表示値だけを正本にしない。
- 共通設定: `config_manager.update_config_keys()`
- 個別設定: `room_manager.update_room_override_key()` / `update_room_override_nested()`
- 起動軽量化後の空 UI 値で保存済み設定を上書きしない。

---

## 5. よくある落とし穴（実害の出た教訓）

1. **UI変更後は実起動で確認する**: Gradioの廃止引数などは `py_compile` /
   `validate_wiring.py` では捕まらず、起動時に初めてクラッシュする。
2. **メニュー位置の記載は現物照合**: ユーザー向け文書・オリヴェのナレッジ・ガイドで
   カラム（左/中央/右）・タブ・アコーディオンに言及する時は、`nexus_ark.py` の実レイアウトと
   突き合わせ、**絵文字を含むラベル文字列を正確に**書く。`visible=False` のタブへ誘導しない
   （位置を誤るとユーザーがメニューを見つけられない実害が出る）。
3. **共有ストアに書き手を追加する時**: 既存の読み手の判定ロジックの暗黙前提を必ず確認する
   （例: 夢ストアへの痕跡書き込みが「今日の夢あり」と誤認され睡眠時整理がスキップされた）。
4. **発信文言の正本はポジショニング文書**: サイト・note・X・配布物の文言と用語は
   `docs/plans/fable/2026-07-09_positioning.md`（§7用語統一・§8ビジュアルアイデンティティ）に従う。
5. **公式サイト（`site/`）は外部リソース読み込み禁止**: フォント・CDN・アナリティクス不可。
   詳細は `site/README.md`。

---

## 6. ドキュメント運用

### 完了レポート

- パス: `docs/reports/YYYY/MM/YYYY-MM-DD_[TaskName].md`
- 含める内容: 問題の概要・修正内容・変更ファイル・検証結果・残課題
- UI変更時は `dev_tools/validate_wiring.py` の実行結果を含める。

### 設計判断記録（ADR）

以下の場合は `docs/decisions/NNN_[Title].md` を作成し、`docs/decisions/README.md` の一覧にも追記する。

- 複数の技術的選択肢から一つを選んだ場合
- 重大な技術的制約により機能を断念した場合
- 将来の開発方針に影響する決定をした場合

---

## 7. 必読ドキュメント・詳細ワークフロー

| ドキュメント | 内容 |
|---|---|
| `docs/guides/gradio_notes.md` | Gradio の罠・トラブルシューティング集（UI変更時必読）|
| `docs/guides/UI_IMPLEMENTATION_PATTERNS.md` | UI実装パターン・安全装置アーキテクチャ |
| `docs/guides/AI_DEVELOPMENT_GUIDELINES.md` | SDK作法・モデル構成・AI開発ルール |
| `docs/guides/SETTINGS_PERSISTENCE_GUIDELINES.md` | 設定保存のガイドライン |
| `docs/guides/RELEASE_NOTES_GUIDELINES.md` | リリースノート執筆ガイドライン（AI草稿→ユーザー確定） |
| `docs/plans/TASK_LIST.md` | 優先順位付きバックログ |
| `docs/INBOX.md` | アイデア・バグ報告の受け口 |
| `docs/STATUS.md` | 現在の開発状況 |
| `docs/decisions/` | アーキテクチャ決定記録（ADR）|
| `docs/plans/fable/2026-07-08_fable_final_handoff.md` | 観察待ち案件・Codex実装のレビュー観点集 |

| ワークフロー | ファイル |
|---|---|
| 開発サイクル全体 | `.agents/workflows/dev-cycle.md` |
| タスク開始 | `.agents/workflows/task-start.md` |
| タスク報告・コミット | `.agents/workflows/task-report.md` |
| タスク完了・マージ | `.agents/workflows/task-complete.md` |
| リリース・自動更新 | `.agents/workflows/release-update.md` |
| バージョニング | `.agents/workflows/versioning.md` |

---

## 8. ツール別の読み替え

- **Claude Code**: `CLAUDE.md` から本ファイルを読み込む。
- **Codex**: `notify_user` 相当は通常返信で行う。`// turbo` 系注記はAntigravity用として無視する。
- **Antigravity**: `.agent/` のワークフローを使う場合も、ルールの正本は本ファイル。

---

**更新履歴**
- 2026-07-10: 初版。`CLAUDE.md`・`.agents/rules/`・`.agent/rules/` に分散していたルールを
  統合し正本化（ADR 020）。§5「よくある落とし穴」を新設。

import datetime
import base64
import os
import subprocess
import traceback
import wave
from typing import Any, Dict, Optional
from urllib.parse import urljoin, urlparse, urlunparse

import google.genai as genai
import google.genai.errors
import requests
from google.genai import types
from openai import OpenAI


MAX_TEXT_LENGTH = 8000
DEFAULT_GEMINI_TTS_MODEL = "gemini-3.1-flash-tts-preview"


def _truncate_text(text: str) -> str:
    if len(text) > MAX_TEXT_LENGTH:
        print(f"  - 警告: テキストが長すぎるため、{MAX_TEXT_LENGTH}文字に切り詰めました。")
        return text[:MAX_TEXT_LENGTH] + "..."
    return text


def _build_prompt(text: str, style_prompt: Optional[str]) -> str:
    text_to_speak = _truncate_text(text or "")
    if style_prompt and style_prompt.strip():
        return f"{style_prompt.strip()}: {text_to_speak}"
    return text_to_speak


def _safe_filename_part(value: Any) -> str:
    safe = "".join(c if c.isalnum() or c in ("-", "_", ".") else "_" for c in str(value or "voice"))
    return safe[:80] or "voice"


def _get_save_path(room_name: str, voice_id: str, extension: str = "wav") -> str:
    save_dir = os.path.join("characters", room_name, "audio_cache")
    os.makedirs(save_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{timestamp}_{_safe_filename_part(voice_id)}.{extension.lstrip('.')}"
    return os.path.abspath(os.path.join(save_dir, filename))


def _normalize_gemini_model_name(model_name: Optional[str]) -> str:
    model = (model_name or DEFAULT_GEMINI_TTS_MODEL).strip()
    return model if model.startswith("models/") else f"models/{model}"


def _write_wav(filepath: str, audio_data: bytes, channels: int = 1, rate: int = 24000, sample_width: int = 2) -> None:
    with wave.open(filepath, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(rate)
        wf.writeframes(audio_data)


def _generate_gemini_tts(
    text: str,
    api_key: str,
    voice_id: str,
    room_name: str,
    style_prompt: Optional[str],
    model_name: Optional[str],
) -> Optional[str]:
    final_prompt = _build_prompt(text, style_prompt)
    model = _normalize_gemini_model_name(model_name)

    print(f"--- 音声生成開始 (Provider: Gemini, Room: {room_name}, Model: {model}, Voice: {voice_id}) ---")
    print(f"  - 最終プロンプト: {final_prompt[:100]}...")

    client = genai.Client(api_key=api_key)
    generation_config_object = types.GenerateContentConfig(
        response_modalities=["AUDIO"],
        speech_config=types.SpeechConfig(
            voice_config=types.VoiceConfig(
                prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice_id)
            )
        ),
    )

    response = client.models.generate_content(
        model=model,
        contents=[types.Content(parts=[types.Part(text=final_prompt)])],
        config=generation_config_object,
    )

    if (
        response
        and response.candidates
        and response.candidates[0].content
        and response.candidates[0].content.parts
        and response.candidates[0].content.parts[0].inline_data
    ):
        audio_data = response.candidates[0].content.parts[0].inline_data.data
        if not audio_data:
            print("--- エラー: API応答のインラインデータが空です ---")
            return None
    else:
        print("--- エラー: API応答に予期した音声データが含まれていませんでした。 ---")
        if response and response.candidates:
            candidate = response.candidates[0]
            finish_reason = candidate.finish_reason.name if hasattr(candidate, "finish_reason") and hasattr(candidate.finish_reason, "name") else "不明"
            safety_ratings = candidate.safety_ratings if hasattr(candidate, "safety_ratings") else "取得不能"
            print(f"  - 終了理由: {finish_reason}")
            print(f"  - 安全性評価: {safety_ratings}")
        return None

    filepath = _get_save_path(room_name, voice_id, "wav")
    _write_wav(filepath, audio_data)
    print(f"  - 音声ファイル(WAV)を生成しました: {filepath}")
    return filepath


def _read_openai_audio_response(response: Any) -> bytes:
    if hasattr(response, "read"):
        return response.read()
    if hasattr(response, "content"):
        return response.content
    if isinstance(response, bytes):
        return response
    return bytes(response)


def _generate_openai_compatible_tts(
    text: str,
    api_key: str,
    voice_id: str,
    room_name: str,
    style_prompt: Optional[str],
    model_name: Optional[str],
    base_url: Optional[str],
    response_format: Optional[str],
    extra_body: Optional[Dict[str, Any]],
) -> Optional[str]:
    model = (model_name or "gpt-4o-mini-tts").strip()
    audio_format = (response_format or "mp3").strip().lower()
    final_prompt = _truncate_text(text or "")

    print(f"--- 音声生成開始 (Provider: OpenAI互換, Room: {room_name}, Model: {model}, Voice: {voice_id}) ---")

    client = OpenAI(api_key=api_key, base_url=base_url) if base_url else OpenAI(api_key=api_key)
    kwargs: Dict[str, Any] = {
        "model": model,
        "voice": voice_id,
        "input": final_prompt,
        "response_format": audio_format,
    }
    if style_prompt and style_prompt.strip() and model.startswith("gpt-4o"):
        kwargs["instructions"] = style_prompt.strip()
    if extra_body:
        kwargs["extra_body"] = extra_body

    response = client.audio.speech.create(**kwargs)
    audio_data = _read_openai_audio_response(response)
    if not audio_data:
        return None

    filepath = _get_save_path(room_name, voice_id, audio_format)
    with open(filepath, "wb") as f:
        f.write(audio_data)
    print(f"  - 音声ファイル({audio_format})を生成しました: {filepath}")
    return filepath


def _generate_elevenlabs_tts(
    text: str,
    api_key: str,
    voice_id: str,
    room_name: str,
    style_prompt: Optional[str],
    model_name: Optional[str],
    response_format: Optional[str],
) -> Optional[str]:
    model = (model_name or "eleven_flash_v2_5").strip()
    audio_format = (response_format or "mp3").strip().lower()
    final_prompt = _build_prompt(text, style_prompt)

    print(f"--- 音声生成開始 (Provider: ElevenLabs, Room: {room_name}, Model: {model}, Voice: {voice_id}) ---")

    output_format = "mp3_44100_128" if audio_format == "mp3" else "pcm_24000"
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    response = requests.post(
        url,
        headers={
            "xi-api-key": api_key,
            "Accept": "audio/mpeg" if audio_format == "mp3" else "audio/wav",
            "Content-Type": "application/json",
        },
        params={"output_format": output_format},
        json={
            "text": final_prompt,
            "model_id": model,
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.75,
            },
        },
        timeout=120,
    )
    if response.status_code >= 400:
        raise RuntimeError(f"ElevenLabs APIエラー: {response.status_code} {response.text[:300]}")

    audio_data = response.content
    if not audio_data:
        return None

    extension = "mp3" if audio_format == "mp3" else "pcm"
    filepath = _get_save_path(room_name, voice_id, extension)
    with open(filepath, "wb") as f:
        f.write(audio_data)
    print(f"  - 音声ファイル({extension})を生成しました: {filepath}")
    return filepath


def _normalize_voicevox_base_url(base_url: Optional[str], provider: str) -> str:
    default_urls = {
        "aivisspeech": "http://127.0.0.1:10101",
        "voicevox": "http://127.0.0.1:50021",
        "coeiroink": "http://127.0.0.1:50032",
    }
    normalized = (base_url or default_urls.get(provider) or default_urls["voicevox"]).strip()
    return normalized.rstrip("/") + "/"


def _is_wsl_environment() -> bool:
    try:
        with open("/proc/version", "r", encoding="utf-8", errors="ignore") as f:
            return "microsoft" in f.read().lower()
    except OSError:
        return False


def _get_wsl_host_ip() -> Optional[str]:
    try:
        with open("/etc/resolv.conf", "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) == 2 and parts[0] == "nameserver":
                    return parts[1]
    except OSError:
        return None
    return None


def _voicevox_engine_url_candidates(base_url: str) -> list[str]:
    candidates = [base_url]
    parsed = urlparse(base_url)
    if parsed.hostname in {"127.0.0.1", "localhost"} and _is_wsl_environment():
        host_ip = _get_wsl_host_ip()
        if host_ip:
            netloc = host_ip
            if parsed.port:
                netloc = f"{host_ip}:{parsed.port}"
            if parsed.username:
                auth = parsed.username
                if parsed.password:
                    auth += f":{parsed.password}"
                netloc = f"{auth}@{netloc}"
            wsl_host_url = urlunparse(parsed._replace(netloc=netloc)).rstrip("/") + "/"
            if wsl_host_url not in candidates:
                candidates.append(wsl_host_url)
    return candidates


def _resolve_voicevox_speaker(base_url: str, voice_id: str) -> int:
    if voice_id and str(voice_id).strip().lower() != "auto":
        return int(str(voice_id).strip())

    response = requests.get(urljoin(base_url, "speakers"), timeout=15)
    response.raise_for_status()
    speakers = response.json()
    for speaker in speakers:
        for style in speaker.get("styles", []):
            style_id = style.get("id")
            if style_id is not None:
                return int(style_id)
    raise RuntimeError("VOICEVOX互換エンジンから話者IDを取得できませんでした。")


def _try_generate_voicevox_compatible_tts(
    text: str,
    voice_id: str,
    room_name: str,
    provider: str,
    engine_url: str,
) -> Optional[str]:
    speaker = _resolve_voicevox_speaker(engine_url, voice_id)

    print(f"--- 音声生成開始 (Provider: {provider}, Room: {room_name}, Engine: {engine_url}, Speaker: {speaker}) ---")

    query_response = requests.post(
        urljoin(engine_url, "audio_query"),
        params={"text": text, "speaker": speaker},
        timeout=30,
    )
    query_response.raise_for_status()

    synthesis_response = requests.post(
        urljoin(engine_url, "synthesis"),
        params={"speaker": speaker},
        json=query_response.json(),
        headers={"Content-Type": "application/json"},
        timeout=120,
    )
    synthesis_response.raise_for_status()

    audio_data = synthesis_response.content
    if not audio_data:
        return None

    filepath = _get_save_path(room_name, f"{provider}_{speaker}", "wav")
    with open(filepath, "wb") as f:
        f.write(audio_data)
    print(f"  - 音声ファイル(WAV)を生成しました: {filepath}")
    return filepath


def _can_use_windows_local_engine_bridge(base_url: str) -> bool:
    parsed = urlparse(base_url)
    return _is_wsl_environment() and parsed.hostname in {"127.0.0.1", "localhost"}


def _build_windows_local_engine_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    return urlunparse(parsed._replace(netloc=f"127.0.0.1:{parsed.port}" if parsed.port else "127.0.0.1")).rstrip("/") + "/"


def _try_generate_voicevox_compatible_tts_via_powershell(
    text: str,
    voice_id: str,
    room_name: str,
    provider: str,
    base_url: str,
) -> Optional[str]:
    engine_url = _build_windows_local_engine_url(base_url)
    text_b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
    voice_b64 = base64.b64encode(str(voice_id or "auto").encode("utf-8")).decode("ascii")
    url_b64 = base64.b64encode(engine_url.encode("utf-8")).decode("ascii")

    script = r"""
$ErrorActionPreference = "Stop"
$text = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("__TEXT_B64__"))
$voiceId = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("__VOICE_B64__"))
$baseUrl = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("__URL_B64__")).TrimEnd('/') + '/'
Add-Type -AssemblyName System.Net.Http
$client = [System.Net.Http.HttpClient]::new()
try {
    if ([string]::IsNullOrWhiteSpace($voiceId) -or $voiceId.ToLowerInvariant() -eq "auto") {
        $speakersResponse = $client.GetAsync($baseUrl + "speakers").Result
        $speakersResponse.EnsureSuccessStatusCode() | Out-Null
        $speakers = $speakersResponse.Content.ReadAsStringAsync().Result | ConvertFrom-Json
        $voiceId = [string]$speakers[0].styles[0].id
    }
    $escapedText = [System.Uri]::EscapeDataString($text)
    $queryUri = $baseUrl + "audio_query?text=" + $escapedText + "&speaker=" + $voiceId
    $queryResponse = $client.PostAsync($queryUri, $null).Result
    $queryResponse.EnsureSuccessStatusCode() | Out-Null
    $queryJson = $queryResponse.Content.ReadAsStringAsync().Result
    $content = [System.Net.Http.StringContent]::new($queryJson, [System.Text.Encoding]::UTF8, "application/json")
    $synthesisUri = $baseUrl + "synthesis?speaker=" + $voiceId
    $synthesisResponse = $client.PostAsync($synthesisUri, $content).Result
    $synthesisResponse.EnsureSuccessStatusCode() | Out-Null
    $bytes = $synthesisResponse.Content.ReadAsByteArrayAsync().Result
    [Console]::Out.WriteLine("VOICE_ID:" + $voiceId)
    [Console]::Out.WriteLine([System.Convert]::ToBase64String($bytes))
} finally {
    $client.Dispose()
}
"""
    script = script.replace("__TEXT_B64__", text_b64).replace("__VOICE_B64__", voice_b64).replace("__URL_B64__", url_b64)
    completed = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=180,
    )
    if completed.returncode != 0:
        raise RuntimeError(f"Windows側の{provider} Engine呼び出しに失敗しました: {completed.stderr.strip() or completed.stdout.strip()}")

    lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    voice_line = next((line for line in lines if line.startswith("VOICE_ID:")), "")
    resolved_voice_id = voice_line.removeprefix("VOICE_ID:") if voice_line else str(voice_id or "auto")
    audio_b64 = next((line for line in reversed(lines) if not line.startswith("VOICE_ID:")), "")
    audio_data = base64.b64decode(audio_b64)
    if not audio_data:
        return None

    filepath = _get_save_path(room_name, f"{provider}_{resolved_voice_id}", "wav")
    with open(filepath, "wb") as f:
        f.write(audio_data)
    print(f"  - Windows側VOICEVOX互換エンジン経由で音声ファイル(WAV)を生成しました: {filepath}")
    return filepath


def _generate_voicevox_compatible_tts(
    text: str,
    voice_id: str,
    room_name: str,
    provider: str,
    base_url: Optional[str],
) -> Optional[str]:
    final_text = _truncate_text(text or "")
    requested_url = _normalize_voicevox_base_url(base_url, provider)
    last_error: Optional[Exception] = None

    for engine_url in _voicevox_engine_url_candidates(requested_url):
        if engine_url != requested_url:
            print(f"  - WSL環境のためWindowsホスト側URLも試行します: {engine_url}")
        try:
            return _try_generate_voicevox_compatible_tts(final_text, voice_id, room_name, provider, engine_url)
        except requests.exceptions.ConnectionError as e:
            last_error = e
            print(f"  - VOICEVOX互換エンジンへ接続できませんでした: {engine_url} ({e})")

    if last_error:
        if _can_use_windows_local_engine_bridge(requested_url):
            print("  - WSLから直接接続できないため、Windows側localhostへPowerShell経由で接続します。")
            return _try_generate_voicevox_compatible_tts_via_powershell(final_text, voice_id, room_name, provider, requested_url)

        provider_labels = {
            "aivisspeech": "AivisSpeech",
            "voicevox": "VOICEVOX",
            "coeiroink": "COEIROINK",
        }
        label = provider_labels.get(provider, provider)
        raise RuntimeError(
            f"{label} Engineに接続できませんでした。エンジンを起動しているか、TTSモデル欄のURL（現在: {requested_url}）とポートを確認してください。"
        ) from last_error
    return None


def generate_audio_from_text(
    text: str,
    api_key: str,
    voice_id: str,
    room_name: str,
    style_prompt: str = None,
    tts_provider: str = "gemini",
    tts_model: str = None,
    base_url: str = None,
    response_format: str = None,
    extra_body: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    指定されたTTSプロバイダで音声を生成し、再生可能な音声ファイルとして保存する。
    既存呼び出し互換のため、デフォルトはGemini TTS。
    """
    try:
        provider = (tts_provider or "gemini").strip().lower()
        if provider == "google":
            provider = "gemini"

        local_voicevox_providers = {"aivisspeech", "voicevox", "coeiroink"}
        if provider not in local_voicevox_providers and (not api_key or str(api_key).startswith("YOUR_API_KEY")):
            return "【エラー】TTS用APIキーが設定されていません。"

        if provider == "gemini":
            return _generate_gemini_tts(text, api_key, voice_id, room_name, style_prompt, tts_model)
        if provider in {"openai", "openai_compatible"}:
            return _generate_openai_compatible_tts(
                text, api_key, voice_id, room_name, style_prompt, tts_model, base_url, response_format or "mp3", extra_body
            )
        if provider == "elevenlabs":
            return _generate_elevenlabs_tts(text, api_key, voice_id, room_name, style_prompt, tts_model, response_format or "mp3")
        if provider in local_voicevox_providers:
            return _generate_voicevox_compatible_tts(text, voice_id, room_name, provider, tts_model)

        return f"【エラー】未対応のTTSプロバイダです: {tts_provider}"

    except google.genai.errors.ClientError as e:
        if "RESOURCE_EXHAUSTED" in str(e) or "429" in str(e):
            error_detail = str(e).upper()
            limit_type = "RPD" if any(
                marker in error_detail
                for marker in (
                    "GENERATEREQUESTSPERDAY",
                    "PERDAY",
                    "PER_DAY",
                    "FREE_TIER_REQUESTS",
                    "DAILY",
                    "RPD",
                )
            ) else "RPM"
            error_message = f"【エラー】音声生成APIの利用上限に達しました（{limit_type}）。しばらく待ってから再試行してください。"
        else:
            error_message = "【エラー】APIリクエストが無効です。プロンプト、モデル、音声名を確認してください。"
        print(f"--- {error_message} 詳細: {e} ---")
        return error_message
    except google.genai.errors.ServerError as e:
        error_message = "【エラー】APIサーバー側で内部エラーが発生しました。一時的な問題の可能性があります。"
        print(f"--- {error_message} 詳細: {e} ---")
        return error_message
    except RuntimeError as e:
        error_message = f"【エラー】{e}"
        print(f"--- {error_message} ---")
        return error_message
    except Exception as e:
        error_message = "【エラー】音声生成中に予期せぬエラーが発生しました。"
        print(f"--- {error_message} 詳細: {e} ---")
        traceback.print_exc()
        return error_message
